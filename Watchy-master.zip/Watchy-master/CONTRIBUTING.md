# How to contribute

### Check out the issue tracker

Search through [Issue tracker](https://github.com/sqfmi/Watchy/issues) for matching topics. It is also recommended to check with current [Pull requests](https://github.com/sqfmi/Watchy/pulls).

### Issue Pull Request

1. Fork this repo and branch out from `dev`.
2. Push commits.
3. Issue pull request.

## Community

- [Discord](https://discord.gg/ZXDegGV8E7)
