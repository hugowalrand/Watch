# Watchy - Fully Open Source E-Paper Watch

![Watchy](https://watchy.sqfmi.com/img/watchy_render.png)

**Buy Watchy from [Mouser](https://www.mouser.com/ProductDetail/SQFMI/SQFMI-WATCHY-10?qs=DRkmTr78QARN9VSJRzqRxw%3D%3D), [The Pi Hut](https://thepihut.com/collections/sqfmi), and [Crowd Supply](https://www.crowdsupply.com/sqfmi/watchy)**

[**Watchy Case & Accessories**](https://shop.sqfmi.com)

## Getting Started Guide
Follow the instructions here https://watchy.sqfmi.com/docs/getting-started

### Have Fun! :)

### Got Questions?

Join our [Discord](https://discord.gg/ZXDegGV8E7)


